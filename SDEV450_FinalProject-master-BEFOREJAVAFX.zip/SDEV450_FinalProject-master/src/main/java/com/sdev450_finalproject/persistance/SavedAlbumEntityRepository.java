package com.sdev450_finalproject.persistance;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SavedAlbumEntityRepository extends JpaRepository<SavedAlbumEntity, Long> {
 
	
}
