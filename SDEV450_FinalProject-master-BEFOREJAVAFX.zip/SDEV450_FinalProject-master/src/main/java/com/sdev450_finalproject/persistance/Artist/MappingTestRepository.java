/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sdev450_finalproject.persistance.Artist;

/**
 *
 * @author Hard
// */
//public interface MappingTestRepository extends JpaRepository<MappingTest, Long>, 
//  QueryDslPredicateExecutor<MappingTest>, QuerydslBinderCustomizer<QMappingTest> {
//  
//    @Override
//    default void customize(QuerydslBindings bindings, QMappingTest root) {
//        bindings.bind(String.class)
//          .first((SingleValueBinding<StringPath, String>) StringExpression::eq);
//    }
//}