package com.sdev450_finalproject.persistance;

public class Follower {

}
